package com.example.myapplication;

import android.Manifest;

import java.util.Arrays;
import java.util.List;

public class Constants {
    public static final int ERROR_DIALOG_REQUEST = 9001;
    public static final int PERMISSIONS_REQUEST_ENABLE_GPS = 9002;
    public static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    public static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    public static final String COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    public static final float DEFAULT_ZOOM = 18;
    public static final int PLACE_PICKER_REQUEST = 1;
    public static final List<String> PRICE_LEVEL_REPRESENTATIONS = Arrays.asList("Çok uygun","Uygun","Pahalı","Çok pahalı");

}
