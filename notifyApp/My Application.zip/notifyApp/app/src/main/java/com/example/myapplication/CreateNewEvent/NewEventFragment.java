package com.example.myapplication.CreateNewEvent;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.myapplication.R;

import java.util.Calendar;

public class NewEventFragment extends Fragment implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private Button nextEventCreateButton;
    private EditText event_name;
    private EditText event_desc;
    private ImageView event_img;
    private TextView event_date;
    private TextView event_time;
    private TextView event_loc;
    private Switch event_hide;

    public NewEventFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_event, container, false);
        nextEventCreateButton = view.findViewById(R.id.submit_event_btn);
        nextEventCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_container, new NewEventMapFragment()).commit();
            }
        });
        getActivity().setTitle("New event");

        //Init
        event_name = view.findViewById(R.id.new_event_name);
        event_desc = view.findViewById(R.id.new_event_desc);
        event_img = view.findViewById(R.id.new_event_img);
        event_date = view.findViewById(R.id.new_event_date_picker);
        event_time = view.findViewById(R.id.new_event_time_picker);
        event_loc = view.findViewById(R.id.new_event_loc_picker);
        event_hide = view.findViewById(R.id.new_event_is_hidden);

        event_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        event_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });

        event_loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        return view;
    }

    private void showLocationPickerDialog(){

    }

    private void showTimePickerDialog(){
        TimePickerDialog timePicker = new TimePickerDialog(
                getActivity(),
                this,
                Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                Calendar.getInstance().get(Calendar.MINUTE),
                //check if date format is 24 hour
                android.text.format.DateFormat.is24HourFormat(getActivity()));
        timePicker.show();
    }

    private void showDatePickerDialog(){
        DatePickerDialog datePicker = new DatePickerDialog(
                getActivity(),
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH) );
        datePicker.show();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String dateText = dayOfMonth + "/" + month + "/" + year;
        event_date.setText(dateText);
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        String timeText = hourOfDay + " : " + minute;
        event_time.setText(timeText);
    }

    //TODO doTheWork();
}
