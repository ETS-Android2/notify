package com.example.myapplication.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.MyObjects.MyEvent;
import com.squareup.picasso.Picasso;

import java.util.List;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class AdapterEventGrid extends RecyclerView.Adapter<AdapterEventGrid.MyEventHolder> {

    private Context mContext;
    private List<MyEvent> eventGridList;

    public AdapterEventGrid(Context mContext, List<MyEvent> eventGridList) {
        this.mContext = mContext;
        this.eventGridList = eventGridList;
    }

    @NonNull
    @Override
    public MyEventHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //Get(create) instance of a card layout
        View view;
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        view = mInflater.inflate(R.layout.event_card_profile, parent, false);
        return new MyEventHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyEventHolder holder, int position) {

        //Get event data to fill the card
        String tempEventName = eventGridList.get(position).getEventName();
        String tempEventDate = eventGridList.get(position).getEventDate().toString();
        String tempEventThumb = eventGridList.get(position).getThumbnail();
        if(tempEventName.length() > 12){
            tempEventName = tempEventName.substring(0,13) + "...";
        }

        //Set data and fill the cardView
        //Set event name, date and thumbnail
        holder.eventName.setText(tempEventName);
        holder.eventDate.setText(tempEventDate);
        try {

            Picasso.get().load(tempEventThumb).placeholder(R.drawable.ic_user).into(holder.thumbnailView);

        }catch (Exception e){

            Log.w(TAG, "Error getting/setting event image on user profile grid layout", e);

        }

        //When item is clicked, ...
        holder.eventCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO goToEventProfile()
            }
        });

    }

    @Override
    public int getItemCount() {
        return eventGridList.size();
    }

    //Single event card view holder subclass
    class MyEventHolder extends RecyclerView.ViewHolder{

        TextView eventName;
        TextView eventDate;
        ImageView thumbnailView;
        CardView eventCard;

        public MyEventHolder(@NonNull View itemView) {
            super(itemView);

            thumbnailView = (ImageView) itemView.findViewById(R.id.event_on_uProfile);
            eventName = (TextView) itemView.findViewById(R.id.eventName_on_uProfile);
            eventDate = (TextView) itemView.findViewById(R.id.eventDate_on_uProfile);
            eventCard = (CardView) itemView.findViewById(R.id.eventCardOnUserProfile);
        }
    }
}
