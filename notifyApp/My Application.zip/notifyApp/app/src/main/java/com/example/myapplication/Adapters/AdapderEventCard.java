package com.example.myapplication.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.example.myapplication.R;
import com.example.myapplication.MyObjects.MyEvent;

import java.util.List;

public class AdapderEventCard extends PagerAdapter {

    private List<MyEvent> eventList;
    private LayoutInflater layoutInflater;
    private Context context;

    public AdapderEventCard(List<MyEvent> eventList, Context context) {
        this.eventList = eventList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return eventList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.event_card,container,false);

        ImageView eventImage;
        TextView eventTitle;
        TextView eventDesc;

        eventImage = view.findViewById(R.id.event_card_img);
        eventTitle = view.findViewById(R.id.event_card_title);
        eventDesc = view.findViewById(R.id.event_card_desc);

        //TODO setImage();
        eventTitle.setText(eventList.get(position).getEventName());
        eventDesc.setText(eventList.get(position).getEventDescription());

        container.addView(view, 0);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }
}
