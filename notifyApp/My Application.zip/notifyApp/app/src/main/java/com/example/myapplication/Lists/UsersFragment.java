package com.example.myapplication.Lists;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Adapters.AdapterUsers;
import com.example.myapplication.R;
import com.example.myapplication.MyObjects.MyUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class UsersFragment extends Fragment {

    RecyclerView recyclerView;
    AdapterUsers adapterUsers;
    List<MyUser> userList;
    FirebaseFirestore db;
    DividerItemDecoration listDivider;

    private static final String TAG = "UserList Fragment: ";


    public UsersFragment() {
        //Constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        getActivity().setTitle("User List");

        //Inflate fragment layout
        View view = inflater.inflate(R.layout.fragment_userlist, container, false);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());

        //Init and set recyclerView
        recyclerView = view.findViewById(R.id.recycler_userlist);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(getContext(), layoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);


        //Init list
        userList = new ArrayList<>();

        //Init db
        db = FirebaseFirestore.getInstance();

        //Get users
        getUsers();

        return view;
    }

    private void getUsers() {

        //Get all users from db
        db.collection("users").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                userList.clear();
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot user : task.getResult()) {
                        //Pars collected data(users) into instances
                        Map<String, Object> userProfileData = user.getData();
                        MyUser singleUser = new MyUser();
                        singleUser.setEmail(userProfileData.get("email").toString());
                        singleUser.setCompany(userProfileData.get("company").toString());
                        singleUser.setName(userProfileData.get("name").toString());
                        singleUser.setPhoneNumber(userProfileData.get("phoneNumber").toString());
                        singleUser.setTitel(userProfileData.get("titel").toString());
                        if (userProfileData.get("profileImage") != null) {
                            singleUser.setProfileImageUri(userProfileData.get("profileImage").toString());
                        } else {
                            singleUser.setProfileImageUri("");
                        }
                        //Add user to the list
                        userList.add(singleUser);

                        //As users added to the list, populate the rows
                        adapterUsers = new AdapterUsers(getActivity(), userList);
                        //Make it efficient
                        recyclerView.setAdapter(adapterUsers);
                    }

                } else {
                    //If task has failed
                    Log.w(TAG, "Database problem on loading user list");
                }
            }

        });

    }
}
