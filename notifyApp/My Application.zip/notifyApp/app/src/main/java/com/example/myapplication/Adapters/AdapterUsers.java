package com.example.myapplication.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.ImageOperations.PicassoCircleTransformation;
import com.example.myapplication.R;
import com.example.myapplication.MyObjects.MyUser;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterUsers extends RecyclerView.Adapter<AdapterUsers.MyUserHolder> {

    private static final String TAG = "AdapterUsers Activity: ";

    Context context;
    List<MyUser> userList;

    public AdapterUsers(Context context, List<MyUser> userList) {
        this.context = context;
        this.userList = userList;
    }

    @NonNull
    @Override
    public MyUserHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //Get(create) instance of a row_user layout
        View view = LayoutInflater.from(context).inflate(R.layout.row_user, parent, false);

        return new MyUserHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyUserHolder holder, int position) {

        //Get user data to fill the row_user
        String userName = userList.get(position).getName();
        String userCompany = userList.get(position).getCompany();
        String userImage = userList.get(position).getProfileImageUri();

        //Set data and fill the row_user
        //Set username and company
        holder.mUsernameView.setText(userName);
        holder.mCompanyView.setText(userCompany);

        //Set profile picture
        try {

            Picasso.get().load(userImage).transform(new PicassoCircleTransformation()).placeholder(R.drawable.ic_user).error(R.drawable.ic_user).into(holder.mUserImageView);

        } catch (Exception e) {

            Log.w(TAG, "Error getting/setting profile image", e);

        }

        //When item is clicked, ...
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO goToProfile();
            }
        });

    }

    @Override
    public int getItemCount() {
        return userList.size();
    }


    //Single user row view holder subclass
    class MyUserHolder extends RecyclerView.ViewHolder {

        TextView mUsernameView;
        TextView mCompanyView;
        ImageView mUserImageView;

        public MyUserHolder(@NonNull View itemView) {
            super(itemView);

            mUsernameView = itemView.findViewById(R.id.user_row_name);
            mCompanyView = itemView.findViewById(R.id.user_row_company);
            mUserImageView = itemView.findViewById(R.id.user_row_img);
        }
    }

}
