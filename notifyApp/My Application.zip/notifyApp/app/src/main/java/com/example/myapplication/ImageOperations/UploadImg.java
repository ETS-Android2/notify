package com.example.myapplication.ImageOperations;

public class UploadImg {
    private String imageUserUid;
    private String imgUrl;
    private String date;

    public UploadImg() {
    }

    public UploadImg(String imageName, String imgUrl, String date) {
        this.imageUserUid = imageName;
        this.imgUrl = imgUrl;
        this.date = date;
    }

    public String getImageName() {
        return imageUserUid;
    }

    public void setImageName(String imageName) {
        this.imageUserUid = imageName;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
