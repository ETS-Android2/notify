package com.example.myapplication.MyObjects;

import com.google.android.libraries.places.api.model.Place;

import java.time.Clock;
import java.util.Date;

public class MyEvent {

    private String organizatorID;
    private String eventName;
    private String eventDescription;
    private Place eventPlace;
    private Date eventDate;
    private Clock eventTime;
    private int eventDurationMinute;
    private float eventRating;
    private String shareRoomId;
    private String chatRoomId;
    private String Thumbnail;

    public MyEvent() {
    }

    public MyEvent(String organizatorID, String eventName, String eventDescription, Place eventPlace, Date eventDate, Clock eventTime, int eventDurationMinute) {
        this.organizatorID = organizatorID;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.eventPlace = eventPlace;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.eventDurationMinute = eventDurationMinute;
    }

    public String getOrganizatorID() {
        return organizatorID;
    }

    public void setOrganizatorID(String organizatorID) {
        this.organizatorID = organizatorID;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public Place getEventPlace() {
        return eventPlace;
    }

    public void setEventPlace(Place eventPlace) {
        this.eventPlace = eventPlace;
    }

    public Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    public Clock getEventTime() {
        return eventTime;
    }

    public void setEventTime(Clock eventTime) {
        this.eventTime = eventTime;
    }

    public int getEventDurationMinute() {
        return eventDurationMinute;
    }

    public void setEventDurationMinute(int eventDurationMinute) {
        this.eventDurationMinute = eventDurationMinute;
    }

    public float getEventRating() {
        return eventRating;
    }

    public void setEventRating(float eventRating) {
        this.eventRating = eventRating;
    }

    public String getShareRoomId() {
        return shareRoomId;
    }

    public void setShareRoomId(String shareRoomId) {
        this.shareRoomId = shareRoomId;
    }

    public String getChatRoomId() {
        return chatRoomId;
    }

    public void setChatRoomId(String chatRoomId) {
        this.chatRoomId = chatRoomId;
    }

    public String getThumbnail() {
        return Thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        Thumbnail = thumbnail;
    }
}
