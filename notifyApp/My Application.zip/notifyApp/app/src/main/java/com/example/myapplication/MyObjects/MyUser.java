package com.example.myapplication.MyObjects;

import java.io.Serializable;

public class MyUser implements Serializable {

    String name, email, phoneNumber, titel, company, profileImageUri;

    public MyUser() {
    }

    //Constructor for one user
    public MyUser(String profileImageUri, String name, String email, String phoneNumber, String titel, String company) {
        this.profileImageUri = profileImageUri;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.titel = titel;
        this.company = company;
    }

    //Getter and setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfileImageUri() {
        return profileImageUri;
    }

    public void setProfileImageUri(String profileImage) {
        this.profileImageUri = profileImage;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getTitel() {
        return titel;
    }

    public void setTitel(String titel) {
        this.titel = titel;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}
